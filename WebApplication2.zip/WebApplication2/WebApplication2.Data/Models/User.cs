﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication2.Data.Models
{
    public class User:IdentityUser
    {
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string pic_url { get; set; }

        public bool InOffice { get; set; }
        public User()
        {
            orders = new HashSet<Order>();
        }
        public ICollection<Order> orders { get; set; }
    }
}
