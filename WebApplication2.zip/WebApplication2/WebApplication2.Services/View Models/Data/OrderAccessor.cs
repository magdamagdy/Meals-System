﻿using Newtonsoft.Json;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebApplication2.Data;
using WebApplication2.Data.Models;

namespace WebApplication2.Services.View_Models.Data
{
    public class OrderAccessor : Repository<Order>
    {
        public OrderAccessor(WebApplication2.Data.AppContext context) : base(context)
        {
        }
        // get whole list 
        public IEnumerable<OrderViewModel> Get()
        {
            return AsQueryable().Select(s => new OrderViewModel
            {
                ID = s.ID,
                StartDate = s.Date,
                //EndDate=s.EndDate,
                Claimed = s.Claimed,
                MealId = s.MealId,
                UserId = s.UserId,
                MealName = s.meal.Type
            });
        }
        // get details of only one trip
        public OrderViewModel Get(int id)
        {
            return AsQueryable().Where(w => w.ID == id).Select(s => new OrderViewModel
            {
                ID = s.ID,
                StartDate = s.Date,
                //EndDate = s.EndDate,
                Claimed = s.Claimed,
                MealId = s.MealId,
                UserId = s.UserId,
                MealName = s.meal.Type

            }).FirstOrDefault();
        }

        // new func to return list of all orders of user 
        public IEnumerable<OrderViewModel> Get(String userid)
        {
            return AsQueryable().Where(w => w.UserId == userid).Select(s => new OrderViewModel
            {
                ID = s.ID,
                StartDate = s.Date,
                //EndDate = s.EndDate,
                Claimed = s.Claimed,
                MealId = s.MealId,
                UserId = s.UserId,
                MealName = s.meal.Type

            });
        }

        // edit function: get all orders of this person by id and search by startdate  
        //if (startdate found) --> Edit
        //else --> create
        public void Add(OrderViewModel model)
        {
            if (model.EndDate == null && (model.StartDate.ToString("dddd") != "Friday" && model.StartDate.ToString("dddd") != "Saturday"))

            {
                List<OrderViewModel> UserOreders = Get(model.UserId).ToList(); //get all orders of this person
                bool flag = false;
                for (int i = 0; i < UserOreders.Count; i += 1)
                {
                    if (model.StartDate.Date == UserOreders[i].StartDate.Date)
                    {
                        model.ID = UserOreders[i].ID;
                        Edit(model);
                        flag = true;
                        break;
                    }
                }
                if (flag == false) //create new order
                {
                    var newmodel = new Order
                    {
                        ID = model.ID,
                        Date = model.StartDate,
                        //EndDate = model.EndDate,
                        Claimed = model.Claimed,
                        MealId = model.MealId,
                        UserId = model.UserId,

                    };
                    Insert(newmodel);
                }

            }

            else
            {
                for (DateTime i = model.StartDate; i <= model.EndDate; i = i.AddDays(1))
                {
                    if (i.ToString("dddd") != "Friday" && i.ToString("dddd") != "Saturday")
                    {
                        List<OrderViewModel> UserOreders = Get(model.UserId).ToList(); //get all orders of this person
                        bool flag = false;
                        for (int j = 0; j < UserOreders.Count; j += 1)
                        {
                            if (i.Date == UserOreders[j].StartDate.Date)
                            {
                                model.ID = UserOreders[j].ID;
                                model.StartDate= UserOreders[j].StartDate;
                                Edit(model);
                                flag = true;
                                break;
                            }
                        }
                        if (flag == false) //create new order
                        {
                            var newmodel = new Order
                            {
                                ID = 0,//model.ID,
                                Date = i,
                                //EndDate = model.EndDate,
                                Claimed = model.Claimed,
                                MealId = model.MealId,
                                UserId = model.UserId,

                            };
                            Insert(newmodel);
                        }
                        
                    }
                }
            }

        } 
        public void Edit(OrderViewModel model)
        {
            var newmodel = new Order
            {
                ID = model.ID,
                Date = model.StartDate,
                //EndDate = model.EndDate,
                Claimed = model.Claimed,
                MealId = model.MealId,
                UserId = model.UserId,
            };
            Update(newmodel);
        }

        public bool Delete(int id)
        {
            var model = AsQueryable().Where(w => w.ID == id).FirstOrDefault();
            if (model != null)
            {
                base.Delete(model);
                return true;
            }
            else
                return false;
        }

        public List<KeyValuePair<int, bool>> Delete(List<OrderViewModel> IDmodel)
        {
            List<KeyValuePair<int, bool>> DeleteLog = new List<KeyValuePair<int, bool>>();
            for (int i=0; i< IDmodel.Count; i++)
            {
                var model = AsQueryable().Where(w => w.ID == IDmodel[i].ID).FirstOrDefault();
                if (model != null)
                {
                    base.Delete(model);
                    DeleteLog.Add(new KeyValuePair<int, bool>(IDmodel[i].ID, true));
                }
                else
                {
                    DeleteLog.Add(new KeyValuePair<int, bool>(IDmodel[i].ID, false));
                }
              
            }
            return DeleteLog;
        }

        public void Claim(OrderViewModel model)
        {
            if ((model.StartDate.ToString("dddd") != "Friday" && model.StartDate.ToString("dddd") != "Saturday"))

            {
                List<OrderViewModel> UserOreders = Get(model.UserId).ToList(); //get all orders of this person

                for (int i = 0; i < UserOreders.Count; i += 1)
                {
                    if (model.StartDate.Date == UserOreders[i].StartDate.Date)
                    {
                        model.ID = UserOreders[i].ID;
                        model.Claimed = true;
                        Edit(model);
                        break;
                    }
                }


            }
        }
        // all claimed for specific date 
        public int ClaimsNumber(DateTime date)
        {
            IEnumerable<OrderViewModel> temp = AsQueryable().Where(w => w.Claimed == true && w.Date.Date == date.Date).Select(s => new OrderViewModel
            {
                ID = s.ID,
                StartDate = s.Date,
                //EndDate = s.EndDate,
                Claimed = s.Claimed,
                MealId = s.MealId,
                UserId = s.UserId,
                MealName = s.meal.Type

            });

            List<OrderViewModel> ClaimedOreders = temp.ToList();
            return ClaimedOreders.Count;
        }

        // all Requested for specific date 
        public int RequestsNumber(DateTime date)
        {
            IEnumerable<OrderViewModel> temp = AsQueryable().Where(w => w.Claimed == false && w.Date.Date == date.Date).Select(s => new OrderViewModel
            {
                ID = s.ID,
                StartDate = s.Date,
                //EndDate = s.EndDate,
                Claimed = s.Claimed,
                MealId = s.MealId,
                UserId = s.UserId,
                MealName = s.meal.Type

            });

            List<OrderViewModel> ClaimedOreders = temp.ToList();
            return ClaimedOreders.Count;
        }
        
        // get the number of each requested meal type
        public List<KeyValuePair<string, int>> ReqMealTypesNum(List<MealViewModel>mealsList, DateTime date)
        {
            int mealsCount = mealsList.Count;
            List<KeyValuePair<string, int>> totalMealCount = new List<KeyValuePair<string, int>>();
            
            for (int i = 0; i < mealsCount; i+=1)
            {
                IEnumerable<OrderViewModel> temp = AsQueryable().Where(w => w.Claimed == false && w.Date.Date == date.Date && w.MealId==mealsList[i].ID).Select(s => new OrderViewModel
                {
                    ID = s.ID,
                    StartDate = s.Date,
                    //EndDate = s.EndDate,
                    Claimed = s.Claimed,
                    MealId = s.MealId,
                    UserId = s.UserId,
                    MealName = s.meal.Type

                });

                List<OrderViewModel> ClaimedOreders = temp.ToList();

                totalMealCount.Add(new KeyValuePair<string, int>(mealsList[i].Type, ClaimedOreders.Count));
                   
            }
            return totalMealCount;
        }

        // get the number of each claimed meal type
        public List<KeyValuePair<string,int>> ClaimMealTypesNum(List<MealViewModel> mealsList, DateTime date)
        {
            int mealsCount = mealsList.Count;
            List<KeyValuePair<string, int>> totalMealCount = new List<KeyValuePair<string, int>>();

            for (int i = 0; i < mealsCount; i += 1)
            {
                IEnumerable<OrderViewModel> temp = AsQueryable().Where(w => w.Claimed == true && w.Date.Date == date.Date && w.MealId == mealsList[i].ID).Select(s => new OrderViewModel
                {
                    ID = s.ID,
                    StartDate = s.Date,
                    //EndDate = s.EndDate,
                    Claimed = s.Claimed,
                    MealId = s.MealId,
                    UserId = s.UserId,
                    MealName = s.meal.Type

                });

                List<OrderViewModel> ClaimedOreders = temp.ToList();

                totalMealCount.Add(new KeyValuePair<string, int>(mealsList[i].Type, ClaimedOreders.Count));

            }
            return totalMealCount;
        }

        
    }

}
