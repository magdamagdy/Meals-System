﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using WebApplication2.Data;
//using WebApplication2.Data.Models;

//namespace WebApplication2.Services.View_Models.Data
//{
//    class RestaurantAccessor: Repository<Order>
//    {
//        public RestaurantAccessor(WebApplication2.Data.AppContext context) : base(context)
//        {
//        }

        
//    }
//}
