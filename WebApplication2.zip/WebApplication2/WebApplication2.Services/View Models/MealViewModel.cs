﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication2.Services.View_Models
{
    public class MealViewModel
    {
        public int ID { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
        public string Components { get; set; }
        public string ImageUrl { get; set; }

    }
}
