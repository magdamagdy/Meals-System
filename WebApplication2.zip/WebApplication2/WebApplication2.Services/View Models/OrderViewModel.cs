﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace WebApplication2.Services.View_Models
{
    public class OrderViewModel
    {
        public int ID { get; set; }

        public DateTime StartDate { get; set; }

        //public DateTime EndDate { get; set; }
        public Nullable<DateTime> EndDate { get; set; }

        public bool Claimed { get; set; }

        public int MealId { get; set; }
        
        public string UserId { get; set; }
        
        public string MealName { get; set; }
        
        //public string QR { get; set; }
    }
}
