﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebApplication2.Data.Models;
using WebApplication2.Services.View_Models;

namespace WebApplication2.Controllers.APIs
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        UserManager<User> userManager;
        private readonly IConfigurationSection _jwtSettings;
        public AccountController(UserManager<User> userManager, IConfiguration configuration)
        {
            this.userManager = userManager;
            _jwtSettings = configuration.GetSection("JwtSettings");
        }
        public object Login(LoginCredentials cred /*string email,string password*/)
        {
            var user = userManager.FindByEmailAsync(cred.email).Result;
            var status_code =0 ;
            var token = "";
            var message = "";
            if (user == null)
            {
                status_code = 0;
                message = "failed";
                return new
                {
                    status_code = status_code,
                    message = message
                };
                
            }
            var result = userManager.CheckPasswordAsync(user, cred.password).Result;
            if (result)
            {
                var signingCredentials = GetSigningCredentials();
                var claims = GetClaims(user);
                var tokenOptions = GenerateTokenOptions(signingCredentials, claims.Result);
                token = new JwtSecurityTokenHandler().WriteToken(tokenOptions);
                status_code = -1;
                message = "success";
            }
            else
            {
                status_code = 1;
                message = "failed";
            }
            List <string> trial= (List<string>)userManager.GetRolesAsync(user).Result;
            //return new { status_code = 2, };
            var role=2;
            List<string> Operator = new List<string>()
                    {
                        "Operator"
                    };
            List<string> Employee = new List<string>()
                    {
                        "Employee"
                    };
            if (trial.FirstOrDefault() == Operator.FirstOrDefault())
            {
                role = 1;
            }
            else if (trial.FirstOrDefault() == Employee.FirstOrDefault())
            {
                role = 0;
            }
            return new
            {
                id = user.Id,
                token = token,
                first_name = user.first_name,
                middle_name = user.middle_name,
                last_name = user.last_name,
                email = user.Email,
                role = role,
                phone = user.PhoneNumber,
                pic_url = user.pic_url,
                status_code = status_code,
                message = message
            };
        }

        [AllowAnonymous] // to be able to access with token instead of username and password
        private SigningCredentials GetSigningCredentials()
        {
            var key = Encoding.UTF8.GetBytes(_jwtSettings.GetSection("securityKey").Value);
            var secret = new SymmetricSecurityKey(key);

            return new SigningCredentials(secret, SecurityAlgorithms.HmacSha512);
        }


        [AllowAnonymous]
        private async Task<List<Claim>> GetClaims(User user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Email, user.Email)
            };
            var roles = await userManager.GetRolesAsync(user);
            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }
            return claims;
        }

        [AllowAnonymous]
        private JwtSecurityToken GenerateTokenOptions(SigningCredentials signingCredentials, List<Claim> claims)
        {
            var tokenOptions = new JwtSecurityToken(
                issuer: _jwtSettings.GetSection("validIssuer").Value,
                audience: _jwtSettings.GetSection("validAudience").Value,
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToDouble(_jwtSettings.GetSection("expiryInMinutes").Value)),
                signingCredentials: signingCredentials);

            return tokenOptions;
        }


        // is in office or not
        public Object InOffice(OrderViewModel model)
        {
            var user = userManager.FindByIdAsync(model.UserId).Result;
            return new
            {
                InOffice = user.InOffice
                
            };

        }
    }
}
