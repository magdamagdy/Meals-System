﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Services;
using WebApplication2.Services.View_Models;
using AppContext = WebApplication2.Data.AppContext;
namespace WebApplication2.Controllers.APIs
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MealController : ControllerBase
    {
        UnitOfWork unitOfWork;
        public MealController(AppContext db)
        {
            unitOfWork = new UnitOfWork(db);
        }

        [HttpGet]
        public IEnumerable<MealViewModel> Get()
        {
            return unitOfWork.Meals.Get();
        }

    }
}
