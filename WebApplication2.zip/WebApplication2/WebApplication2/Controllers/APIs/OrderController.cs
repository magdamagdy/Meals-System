﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Services;
using WebApplication2.Services.View_Models;
using AppContext = WebApplication2.Data.AppContext;

namespace WebApplication2.Controllers.APIs
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        UnitOfWork unitOfWork;
        public OrderController(AppContext db)
        {
            unitOfWork = new UnitOfWork(db);
        }

        [HttpGet]
        public IEnumerable<OrderViewModel> Get()
        {
            return unitOfWork.Order.Get();
        }

        //[HttpPost]
        //public object Post(string id)
        //{
        //    unitOfWork.Order.Get(id);
        //    return new { IsSuccess = true };
        //}

        //[HttpPost]
        //public object Get2([FromBody] string id) //??? check input string
        //{
        //    Get3(id);
        //    return new { IsSuccess = true };
        //}
        //[HttpPost]
        //public IEnumerable<OrderViewModel> Get3(string id) //??? check input string
        //{
        //    return unitOfWork.Order.Get(id);
        //}

        public object GetById(OrderViewModel model)  
        {
            var x = unitOfWork.Order.Get(model.UserId);
            if (x != null && x.Any())
            {
                return new { list = x, IsSuccess = true };
            }
            else return new { IsSuccess = false };

        }


        [HttpPost]
        public object Add(OrderViewModel model)
        {
            unitOfWork.Order.Add(model);
            unitOfWork.Commit();
            return new { IsSuccess = true };
        }
        [HttpPost]
        public object Edit(OrderViewModel model)
        {
            unitOfWork.Order.Edit(model);
            unitOfWork.Commit();
            return new { IsSuccess = true };
        }

        public object Delete(OrderViewModel model)
        {
            var result = unitOfWork.Order.Delete(model.ID);
            unitOfWork.Commit();
            return new { IsSuccess = result };
        }
        public object Delete2(List<OrderViewModel>model)
        {
            var result = unitOfWork.Order.Delete(model);
            unitOfWork.Commit();
            return new { IsSuccess = result };
        }

        //Claiming 
        public object ScanQR(OrderViewModel model)
        {
            unitOfWork.Order.Claim(model);
            unitOfWork.Commit();
            return new { IsSuccess = true };
        }

        

    }
}
