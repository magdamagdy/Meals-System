﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Services;
using WebApplication2.Services.View_Models;
using AppContext = WebApplication2.Data.AppContext;
namespace WebApplication2.Controllers.APIs
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class RestaurantController : ControllerBase
    {
        UnitOfWork unitOfWork;
        public RestaurantController(AppContext db)
        {
            unitOfWork = new UnitOfWork(db);
        }

        //public object ClaimsNumber(DateTime date)
        //{
        //    var x = unitOfWork.Order.ClaimsNumber(date);
        //    return new { ClaimedMealsNum = x, IsSuccess = true };
        //}
        //public object RequestsNumber(DateTime date)
        //{
        //    var x = unitOfWork.Order.RequestsNumber(date);
        //    return new { RequestedMealsNum = x, IsSuccess = true };
        //}
        //public object RequestTypesNumber(DateTime date)
        //{
        //    List<MealViewModel> meals = unitOfWork.Meals.Get().ToList();
        //    var x = unitOfWork.Order.ReqMealTypesNum(meals, date);
          
        //    return new { list = x, IsSuccess = true };
        //}
        //public object ClaimTypesNumber(DateTime date)
        //{
        //    List<MealViewModel> meals = unitOfWork.Meals.Get().ToList();
        //    var x = unitOfWork.Order.ClaimMealTypesNum(meals, date);

        //    return new { list = x, IsSuccess = true };
        //}
        public object HomeClaims(OrderViewModel model)
        {
            var ClaimedMealsNum = unitOfWork.Order.ClaimsNumber(model.StartDate);
            var RequestedMealsNum = unitOfWork.Order.RequestsNumber(model.StartDate);

            List<MealViewModel> meals = unitOfWork.Meals.Get().ToList();
            var ReqMealTypesNum = unitOfWork.Order.ReqMealTypesNum(meals, model.StartDate);
            var ClaimMealTypesNum = unitOfWork.Order.ClaimMealTypesNum(meals, model.StartDate);
            
            return new { ClaimedMealsNum = ClaimedMealsNum,
                RequestedMealsNum= RequestedMealsNum,
                ClaimMealTypesNum= ClaimMealTypesNum,
                ReqMealTypesNum = ReqMealTypesNum,
                IsSuccess = true };
        }
    }
}
